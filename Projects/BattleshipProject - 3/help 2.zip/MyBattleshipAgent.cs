﻿using System;

namespace Battleship
{
    public class FrankSinatra : BattleshipAgent
    {
        char[,] attackHistory;
        GridSquare attackGrid;

        int hits;//17   c = 5   b = 4   d = 3  s = 3  p = 2  

        int misses;
        GridSquare[] bHits;//what
        bool bHasBeenHit = false;
        bool bIsSunk = false;
        GridSquare[] cHits;//do I
        bool cHasBeenHit = false;
        bool cIsSunk = false;
        GridSquare[] dHits;//do
        bool dHasBeenHit = false;
        bool dIsSunk = false;
        GridSquare[] sHits;//with
        bool sHasBeenHit = false;
        bool sIsSunk = false;
        GridSquare[] pHits;//these
        bool pHasBeenHit = false;
        bool pIsSunk = false;


        public FrankSinatra()
        {
            attackHistory = new char[10, 10];
            attackGrid = new GridSquare();
        }

        public override string ToString()
        {
            return $"Battleship Agent '{GetNickname()}'";
        }

        public override string GetNickname()
        {
            return "Franc";
        }

        public override void SetOpponent(string opponent)
        {
            return;
        }

        public override GridSquare LaunchAttack()
        {
            /*if (attackHistory[attackGrid.x, attackGrid.y] != '\0')
            {
                attackGrid.x = attackGrid.x + 1;
                return attackGrid;
            }
            if (attackHistory[attackGrid.x-1, attackGrid.y] != '\0')
            {
                attackGrid.x = attackGrid.x - 2;
                return attackGrid;
            }
            if (attackHistory[attackGrid.x + 1, attackGrid.y] != '\0')
            {
                attackGrid.x = attackGrid.x + 1;
                attackGrid.y = attackGrid.y + 1;
                return attackGrid;
            }
            if (attackHistory[attackGrid.x, attackGrid.y - 1] != '\0')
            {
                attackGrid.y = attackGrid.y - 2;
                return attackGrid;
            }*/

            Random tempX = new Random(); int x = tempX.Next(10);
            Random tempY = new Random(); int y = tempY.Next(10);

            //first move
            if (misses == 0)
                {
                    attackGrid.x = tempX.Next(10);
                    attackGrid.y = tempY.Next(10);
                    return attackGrid;
                }
            //doesn't allow a the same move to be repeated twice
            while (x == attackGrid.x && y == attackGrid.y)
            {
                x = tempX.Next(10);
                y = tempY.Next(10);
            }

            attackGrid.x = x;
            attackGrid.y = y;
            return attackGrid;
        }

        public override void DamageReport(char report)
        {
            attackHistory[attackGrid.x, attackGrid.y] = report;
            Random shot = new Random();

            if (report != '\0')
            {
                hits++;
                if (report == 'c')
                {
                    cHasBeenHit = true;
                }
                if (report == 'b') 
                { 
                    bHasBeenHit = true; 
                }
                if (report == 'd') 
                { 
                    dHasBeenHit = true; 
                }
                if (report == 's') 
                { 
                    sHasBeenHit = true; 
                }
                if (report == 'p') 
                { 
                    pHasBeenHit = true; 
                }
            }
            else { misses++; }
        }

        public override BattleshipFleet PositionFleet()
        {
            BattleshipFleet myFleet = new BattleshipFleet();
            Random myRand = new Random();
            

            myFleet.Carrier = new ShipPosition(myRand.Next(5),myRand.Next(1), ShipRotation.Vertical);
            myFleet.Battleship = new ShipPosition(6, myRand.Next(7, 9), ShipRotation.Horizontal);
            myFleet.Destroyer = new ShipPosition(myRand.Next(1, 3), 7, ShipRotation.Vertical);
            myFleet.Submarine = new ShipPosition(6, myRand.Next(0, 2), ShipRotation.Horizontal);
            myFleet.PatrolBoat = new ShipPosition(myRand.Next(6, 9), myRand.Next(3, 5), ShipRotation.Vertical);

            return myFleet;
        }
    }
}
